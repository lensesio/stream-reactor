//------------------------------------------------------------------------------
// <copyright project="BEmu_maven" file="/BEmu_maven/bemu/src/main/java/com/bloomberglp/blpapi/Constant.java" company="Jordan Robinson">
//     Copyright (c) 2013 Jordan Robinson. All rights reserved.
//
//     The use of this software is governed by the Microsoft Public License
//     which is included with this distribution.
// </copyright>
//------------------------------------------------------------------------------

package com.bloomberglp.blpapi;

public class Constant
{
	public Constant() throws Exception
	{
		throw new Exception("not implemented");
	}

	public void setUserData(Object arg0) throws Exception
	{
		throw new Exception("not implemented");
	}

	public Name name() throws Exception
	{
		throw new Exception("not implemented");
	}

	public String description() throws Exception
	{
		throw new Exception("not implemented");
	}

	public Schema.Status status() throws Exception
	{
		throw new Exception("not implemented");
	}

	public Schema.Datatype datatype() throws Exception
	{
		throw new Exception("not implemented");
	}

	public char getValueAsChar() throws Exception
	{
		throw new Exception("not implemented");
	}

	public int getValueAsInt32() throws Exception
	{
		throw new Exception("not implemented");
	}

	public long getValueAsInt64() throws Exception
	{
		throw new Exception("not implemented");
	}

	public float getValueAsFloat32() throws Exception
	{
		throw new Exception("not implemented");
	}

	public double getValueAsFloat64() throws Exception
	{
		throw new Exception("not implemented");
	}

	public String getValueAsString() throws Exception
	{
		throw new Exception("not implemented");
	}

	public Datetime getValueAsDatetime() throws Exception
	{
		throw new Exception("not implemented");
	}

	public Datetime getValueAsDate() throws Exception
	{
		throw new Exception("not implemented");
	}

	public Datetime getValueAsTime() throws Exception
	{
		throw new Exception("not implemented");
	}

	public Object userData() throws Exception
	{
		throw new Exception("not implemented");
	}
}
