//------------------------------------------------------------------------------
// <copyright project="BEmu_maven" file="/BEmu_maven/bemu/src/main/java/com/bloomberglp/blpapi/Constraint.java" company="Jordan Robinson">
//     Copyright (c) 2013 Jordan Robinson. All rights reserved.
//
//     The use of this software is governed by the Microsoft Public License
//     which is included with this distribution.
// </copyright>
//------------------------------------------------------------------------------

package com.bloomberglp.blpapi;

public class Constraint
{
	public Constraint() throws Exception
	{
		throw new Exception("not implemented");
	}
	
	public Name constraintType() throws Exception
	{
		throw new Exception("not implemented");
	}
	
	public ConstantsList values() throws Exception
	{
		throw new Exception("not implemented");
	}
}
