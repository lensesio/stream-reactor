//------------------------------------------------------------------------------
// <copyright project="BEmu_maven" file="/BEmu_maven/bemu/src/main/java/com/bloomberglp/blpapi/ConstantsList.java" company="Jordan Robinson">
//     Copyright (c) 2013 Jordan Robinson. All rights reserved.
//
//     The use of this software is governed by the Microsoft Public License
//     which is included with this distribution.
// </copyright>
//------------------------------------------------------------------------------

package com.bloomberglp.blpapi;

public class ConstantsList
{
	public void setUserData(Object arg0) throws Exception
	{
		throw new Exception("not implemented");
	}
	
	public Name name() throws Exception
	{
		throw new Exception("not implemented");
	}
	
	public String description() throws Exception
	{
		throw new Exception("not implemented");
	}
	
	public Schema.Status status() throws Exception
	{
		throw new Exception("not implemented");
	}
	
	public Schema.Datatype datatype() throws Exception
	{
		throw new Exception("not implemented");
	}
	
	public Object userData() throws Exception
	{
		throw new Exception("not implemented");
	}
	
	public boolean hasConstant(Name arg0) throws Exception
	{
		throw new Exception("not implemented");
	}
	
	public boolean hasConstant(String arg0) throws Exception
	{
		throw new Exception("not implemented");
	}
	
	public Constant getConstant(Name arg0) throws Exception
	{
		throw new Exception("not implemented");
	}
	
	public Constant getConstant(String arg0) throws Exception
	{
		throw new Exception("not implemented");
	}
	
	public int numConstants() throws Exception
	{
		throw new Exception("not implemented");
	}
	
	public Constant constantAt(int arg0) throws Exception
	{
		throw new Exception("not implemented");
	}
}
