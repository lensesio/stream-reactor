//------------------------------------------------------------------------------
// <copyright project="BEmu_maven" file="/BEmu_maven/bemu/src/main/java/com/bloomberglp/blpapi/ConstraintsList.java" company="Jordan Robinson">
//     Copyright (c) 2013 Jordan Robinson. All rights reserved.
//
//     The use of this software is governed by the Microsoft Public License
//     which is included with this distribution.
// </copyright>
//------------------------------------------------------------------------------

package com.bloomberglp.blpapi;

public class ConstraintsList
{
	public ConstraintsList() throws Exception
	{
		throw new Exception("not implemented");
	}
	
	public boolean hasConstraint(Name arg0) throws Exception
	{
		throw new Exception("not implemented");
	}
	
	public Constraint constraint(Name arg0) throws Exception
	{
		throw new Exception("not implemented");
	}
	
	public int numConstraints() throws Exception
	{
		throw new Exception("not implemented");
	}
	
	public Constraint constraintAt(int arg0) throws Exception
	{
		throw new Exception("not implemented");
	}	
}
