package com.bloomberglp.blpapi;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class ElementIterator implements Iterator<Element> {
    private Element o;
    private boolean p = true;
    private int q;
    private int r;

    ElementIterator(Element var1) {
        this.o = var1;
        this.q = 0;
        this.r = var1.numElements();
        try {
            this.p = var1.isComplexType() && this.q < this.r;
        } catch (Exception e) {

        }
    }

    public boolean hasNext() {
        return this.p;
    }

    public Element next() {
        if (!this.p) {
            throw new NoSuchElementException();
        } else {
            Element var1 = null;

            try {
                var1 = this.o.getElement(this.q);
            } catch (Throwable var3) {
                throw new NoSuchElementException();
            }

            ++this.q;
            this.p = this.q < this.r;
            return var1;
        }
    }

    public void remove() {
        throw new UnsupportedOperationException();
    }
}
