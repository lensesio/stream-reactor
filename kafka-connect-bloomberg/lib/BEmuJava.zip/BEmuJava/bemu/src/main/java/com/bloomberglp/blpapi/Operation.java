//------------------------------------------------------------------------------
// <copyright project="BEmu_maven" file="/BEmu_maven/bemu/src/main/java/com/bloomberglp/blpapi/Operation.java" company="Jordan Robinson">
//     Copyright (c) 2013 Jordan Robinson. All rights reserved.
//
//     The use of this software is governed by the Microsoft Public License
//     which is included with this distribution.
// </copyright>
//------------------------------------------------------------------------------

package com.bloomberglp.blpapi;

public class Operation
{
	public Name name() throws Exception
	{
		throw new Exception ("not implemented");
	}
	
	public Schema.Status status() throws Exception
	{
		throw new Exception ("not implemented");
	}
	
	public SchemaTypeDefinition requestType() throws Exception
	{
		throw new Exception ("not implemented");
	}
	
	public SchemaElementDefinition requestDefinition() throws Exception
	{
		throw new Exception ("not implemented");
	}
	
	public SchemaTypeDefinition[] responseType() throws Exception
	{
		throw new Exception ("not implemented");
	}
	
	public int numResponseDefinitions() throws Exception
	{
		throw new Exception ("not implemented");
	}
	
	public SchemaElementDefinition responseDefinition(int arg0) throws Exception
	{
		throw new Exception ("not implemented");
	}
	
	public String description() throws Exception
	{
		throw new Exception ("not implemented");
	}	
}
