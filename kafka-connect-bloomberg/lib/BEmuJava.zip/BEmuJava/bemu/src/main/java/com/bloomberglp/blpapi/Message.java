//------------------------------------------------------------------------------
// <copyright project="BEmu_maven" file="/BEmu_maven/bemu/src/main/java/com/bloomberglp/blpapi/Message.java" company="Jordan Robinson">
//     Copyright (c) 2013 Jordan Robinson. All rights reserved.
//
//     The use of this software is governed by the Microsoft Public License
//     which is included with this distribution.
// </copyright>
//------------------------------------------------------------------------------

package com.bloomberglp.blpapi;

import java.io.OutputStream;
import java.io.Writer;

public abstract class Message {
    private Service _service;

    public Service service() {
        return this._service;
    }

    private Name _messageType;

    public Name messageType() {
        return this._messageType;
    }

    private CorrelationID _correlationID;

    public CorrelationID correlationID() {
        return this._correlationID;
    }

    protected Message(Name messageType, CorrelationID corr, Service service) {
        this._correlationID = corr;
        this._messageType = messageType;
        this._service = service;
    }

    protected Message() {
        this(new Name("mock"), new CorrelationID(), null);
    }

    public Element asElement() throws Exception {
        throw new Exception("not implemented");
    }

    public Element getElement(Name name) throws Exception {
        return this.getElement(name.toString());
    }

    public Element getElement(String name) throws Exception {
        throw new Exception("not implemented");
    }

    public boolean hasElement(String name, boolean excludeNullElements) throws Exception {
        throw new Exception("not implemented");
    }

    public boolean hasElement(String name) throws Exception {
        return this.hasElement(name, false);
    }

    public boolean hasElement(Name name, boolean excludeNullElements) throws Exception {
        return this.hasElement(name.toString(), excludeNullElements);
    }

    public boolean hasElement(Name name) throws Exception {
        return this.hasElement(name.toString());
    }

    public int numElements() throws Exception {
        throw new Exception("not implemented");
    }

    public int numValues() throws Exception {
        throw new Exception("not implemented");
    }

    public String topicName() throws Exception {
        throw new Exception("not implemented");
    }

    public double getElementAsFloat64(Name name) throws Exception {
        return this.getElement(name).getValueAsFloat64();
    }

    public double getElementAsFloat64(String name) throws Exception {
        return this.getElement(name).getValueAsFloat64();
    }

    public float getElementAsFloat32(Name name) throws Exception {
        return this.getElement(name).getValueAsFloat32();
    }

    public float getElementAsFloat32(String name) throws Exception {
        return this.getElement(name).getValueAsFloat32();
    }

    public long getElementAsInt64(Name name) throws Exception {
        return this.getElement(name).getValueAsInt64();
    }

    public long getElementAsInt64(String name) throws Exception {
        return this.getElement(name).getValueAsInt64();
    }

    public int getElementAsInt32(Name name) throws Exception {
        return this.getElement(name).getValueAsInt32();
    }

    public int getElementAsInt32(String name) throws Exception {
        return this.getElement(name).getValueAsInt32();
    }

    public String getElementAsString(Name name) throws Exception {
        return this.getElement(name).getValueAsString();
    }

    public String getElementAsString(String name) throws Exception {
        return this.getElement(name).getValueAsString();
    }

    public Datetime getElementAsDatetime(String name) throws Exception {
        return this.getElement(name).getValueAsDatetime();
    }

    public Datetime getElementAsDatetime(Name name) throws Exception {
        return this.getElement(name).getValueAsDatetime();
    }

    public Datetime getElementAsDate(String name) throws Exception {
        return this.getElement(name).getValueAsDate();
    }

    public Datetime getElementAsDate(Name name) throws Exception {
        return this.getElement(name).getValueAsDate();
    }

    public Datetime getElementAsTime(Name name) throws Exception {
        return this.getElement(name).getValueAsTime();
    }

    public Datetime getElementAsTime(String name) throws Exception {
        return this.getElement(name).getValueAsTime();
    }

    public boolean getElementAsBool(Name name) throws Exception {
        return this.getElement(name).getValueAsBool();
    }

    public boolean getElementAsBool(String name) throws Exception {
        return this.getElement(name).getValueAsBool();
    }

    public byte[] getElementAsBytes(Name name) throws Exception {
        return this.getElement(name).getValueAsBytes();
    }

    public byte[] getElementAsBytes(String name) throws Exception {
        //return this.getElement(name).getvalueas
        return null;
    }

    public char getElementAsChar(Name name) throws Exception {
        return this.getElement(name).getValueAsChar();
    }

    public char getElementAsChar(String name) throws Exception {
        return this.getElement(name).getValueAsChar();
    }

    public Name getElementAsName(Name name) {
        throw new UnsupportedOperationException();
    }

    public Name getElementAsName(String s) {
        throw new UnsupportedOperationException();
    }

    public int numCorrelationIds() {
        throw new UnsupportedOperationException();
    }

    public CorrelationID correlationID(int i) {
        throw new UnsupportedOperationException();
    }

    public boolean isValid() {
        return false;
    }

    public long timeReceivedMillis() {
        throw new UnsupportedOperationException();
    }

    public CorrelationID correlationIDAt(int i) {
        throw new UnsupportedOperationException();
    }

    public void print(Writer writer) {

    }

    public void print(OutputStream outputStream) {

    }

    public Fragment fragmentType() {
        return Fragment.NONE;
    }

    public static enum Fragment {
        NONE,
        START,
        INTERMEDIATE,
        END;

        private Fragment() {
        }
    }

}
